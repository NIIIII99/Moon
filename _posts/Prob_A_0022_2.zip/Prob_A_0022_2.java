package swcert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
/*
1
10/22 02:52:48 
 */
public class Prob_A_0022_2 {

	static List<Integer>[] data = new List[36];
	static int[] distance, numCnt, engCnt;
	static boolean[][][] visited;
	public static void main(String[] args) throws Exception {
		for(int i=0;i<=35;i++) {
			data[i] = new ArrayList<Integer>();
		}
		setKeyboard();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		int T = Integer.parseInt(br.readLine());
		for(int t=1;t<=T;t++) {
			String input = br.readLine();
			int month = Integer.parseInt(input.substring(0, 2));
			int day = Integer.parseInt(input.substring(3, 5));
			int hour = Integer.parseInt(input.substring(6, 8));
			int minute = Integer.parseInt(input.substring(9, 11));
			int second = Integer.parseInt(input.substring(12, 14));

			int first = (day+second) % 36;
			int last = (month+hour+minute)%36;
			int minNumCnt = minute/10;
			int upperCnt = second/10;
			//	bw.write(first +" "+last+" "+minNumCnt+" "+upperCnt);

			visited = new boolean[11][36][36];
			distance = new int[36];
			numCnt = new int[36];
			engCnt = new int[36];
			//dp[i][j] = prev->i��� ���� ���µ� j �Ÿ��� �ɸ�
			//dp[i][j] = i������ j�Ÿ� = ����cnt
			int[][] dp = new int[36][36];//i������ j�Ÿ��̸鼭 ���ڰ����� k�� ����� ��
			boolean[][][] path = new boolean[11][36][36]; // path[lv][next] = cur;
			
			//dp[i][j] = dp[i-1][j-1]+1;
			
			//���ڱ���
			int lvCnt=1;			
			Queue<Integer> que = new LinkedList<Integer>();
			Queue<Integer> queTmp = new LinkedList<Integer>();		
			
			que.add(first);
			while(!que.isEmpty() && lvCnt <= 10) {				
				int cur = que.poll();
				for(int next : data[cur]) {					
					if(!visited[lvCnt][cur][next]) {
						visited[lvCnt][cur][next] = true;
						if(next<=9) {
							dp[next][lvCnt] = dp[cur][lvCnt-1]+1;
						}else {
							dp[next][lvCnt] = dp[cur][lvCnt-1];
						}
//						if(cur==7&&next==8&&lvCnt==6) {
//							System.out.println("<<<"+dp[7][5]);
//							System.out.println("<<<"+dp[8][6]);
//						}
//						if(next==8&&lvCnt==6) {
//							System.out.println(">>>"+cur+":"+dp[8][6]);
//						}
						queTmp.add(next);
					}
				}
				if(que.isEmpty() && !queTmp.isEmpty()) {
					lvCnt++;
					que.addAll(queTmp);
					queTmp.clear();
				}
			}
			
//			System.out.println("34: "+ dp[34][1]);
//			System.out.println("25: "+ dp[25][2]);
//			System.out.println("15: "+ dp[15][3]);
//			System.out.println("6: "+ dp[6][4]);
//			System.out.println("7: "+ dp[7][5]);
//			System.out.println("8: "+ dp[8][6]);
//			System.out.println("9: "+ dp[9][7]);
//			System.out.println("0: "+ dp[0][8]);
//			System.out.println("19: "+ dp[19][9]);
//			System.out.println("28: "+ dp[28][10]);
			int node = last;
			
			for(int i=0;i<=35;i++) {
				if(visited[9][i][28]) {
					System.out.println(i);					
				}
				
			}
			
//			for(int i=9;i>=1;i--) {
//				for(int j=0;j<=35;j++) {
//					for(int k=0;k<=35;k++) {
//						if(visited[i][j][k]) {
//							System.out.println(i+":"+visit[i][node][]);							
//						}
//						
//					}					
//				}
//			}
			
		}
		bw.flush();

	}


	private static void setKeyboard() {
		//0
		data[0].add(1);
		data[0].add(10);
		//1~8
		for(int i=1;i<=8;i++) {
			data[i].add(i-1);
			data[i].add(i+1);
			data[i].add(i+9);
			data[i].add(i+10);
			data[i].add(i+11);
		}
		//9
		data[9].add(8);
		data[9].add(18);
		data[9].add(19);
		//10
		data[10].add(0);
		data[10].add(1);
		data[10].add(11);
		data[10].add(20);

		//11~18

		for(int i=11;i<=18;i++) {
			data[i].add(i-10);
			data[i].add(i-9);
			data[i].add(i-1);
			data[i].add(i+1);
			data[i].add(i+9);
			data[i].add(i+10);
		}

		//19

		data[19].add(9);

		data[19].add(18);

		data[19].add(28);

		//20

		data[20].add(10);

		data[20].add(11);

		data[20].add(21);

		data[20].add(29);

		//21~26

		for(int i=21;i<=26;i++) {

			data[i].add(i-10);

			data[i].add(i-9);

			data[i].add(i-1);

			data[i].add(i+1);

			data[i].add(i+8);

			data[i].add(i+9);

		}

		//27

		data[27].add(17);

		data[27].add(18);

		data[27].add(26);

		data[27].add(28);

		data[27].add(35);

		//28

		data[28].add(18);

		data[28].add(19);

		data[28].add(27);

		//29

		data[29].add(20);

		data[29].add(21);

		data[29].add(30);

		//30~34

		for(int i=30;i<=34;i++) {

			data[i].add(i-9);

			data[i].add(i-8);

			data[i].add(i-1);

			data[i].add(i+1);

		}

		//35

		data[35].add(26);

		data[35].add(27);

		data[35].add(34);


	}

}
